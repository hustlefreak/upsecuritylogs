<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('visitor_attendances', function (Blueprint $table) {
            $table->dropColumn('badge_returned');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('visitor_attendances', function (Blueprint $table) {
            $table->boolean('badge_returned')->default(false);
        });
    }
};
